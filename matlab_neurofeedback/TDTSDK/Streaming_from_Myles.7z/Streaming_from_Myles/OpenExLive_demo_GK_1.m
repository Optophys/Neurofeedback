%% Housekeeping by Golan
clearvars -except z zz
close all; clc;
addpath(genpath('C:\MatlabPrograms\TDTSDK\Streaming_from_Myles'));
%% Setup
EVENT1 = 'Powr';
EVENT2 = 'test';
t = OpenExLive();
t.VERBOSE = false;

%% Parameters
time_to_plot    = 3;        %in seconds
freqs           = 15:30;    %to plot, in Hz
medians_time    = 10;       %in seconds
group_delay     = 130;      %in samples
art_thrsh       = 450;      %raw LFP to be rejected, in uV
art_time        = 300;      %rejected time around artifact, in samples
do_plot         = 1;        %bool, 1 means plotting
%% Main Loop
figure('position',[314 396 1574 707]);
first_pass = true;
b = true;
n=1;
prev_samp = 0;
arts = [];
whole_pows = [];
whole_raws = [];
LFP_clean = [];
Pix_clean = [];
debt = [];

tsst = []; %delete me
gssss = 0; %delete me

while b
    % slow it down
    pause(1)
    
    % get the most recent data, exit loop if the block has stopped.
    tic
    try t.update();
    catch b=0; disp('Block stopped?'); end
    
    % grab the latest events
    pows = t.get_data(EVENT1);
    whole_pows = [whole_pows, pows.data];
    read_pows{n} = pows.data;
    pows.data = whole_pows;
    
    raws = t.get_data(EVENT2);
    whole_raws = [whole_raws, raws.data];
    read_raws{n} = raws.data;
    raws.data = whole_raws;
    
    % calculations and plotting
    if isstruct(pows)
        if do_plot
            subplot(4,1,1:3);
            [ts, samps] = time_limit_plot_inds (time_to_plot, whole_pows, pows.fs);
            imagesc(ts, freqs, whole_pows(freqs,samps));
            axis xy; colormap jet; colorbar('northoutside');
            title('Power'); ylabel('Frequency (Hz)')
            
            subplot(414);
            % use the same time stamps for raw as for power
            try plot(ts,whole_raws(:,samps - group_delay)'); end
            set(gca,'xlim',[ts(1), ts(end)]);
            title('Raw'); xlabel('Time (sec)'); ylabel('\muV');
        end
        
        % find gross artifacts.
        % Deamean the data, will take ~9 ms after 16 minuts, ~90 ms after 2hrs:45min
        raw = raws.data - mean(raws.data);
        
        % Run only over the new data
        siz = size(pows.data);
        Pix = pows.data(:,prev_samp+1 : end);
        LFP = raw(prev_samp+1 : end);
        new_arts = find(abs(LFP) > art_thrsh);
        
        % put NaNs at the "debt" from the previous read
        Pix (:,1:debt) = NaN;
        LFP (1:debt) = NaN;
        
        debt = [];
        % Put NaNs around the artifacts
        for arin = new_arts
            if arin <= art_time
                LFP   (1 : arin + art_time) = NaN;
                Pix (:,1 : arin + art_time) = NaN;
            elseif arin >= (length(LFP) - art_time)
                LFP   (arin - art_time : end) = NaN;
                Pix (:,arin - art_time : end) = NaN;
                debt = art_time - (siz(2)-arin);
            else
                LFP   (arin - art_time : arin + art_time) = NaN;
                Pix (:,arin - art_time : arin + art_time) = NaN;
            end
        end
        Pix_clean = [Pix_clean, Pix];
        LFP_clean = [LFP_clean, LFP];
        
        arts = [arts, new_arts + prev_samp]; %not really necessary
        
        prev_samp = siz(2);
        prev_samps(n) = siz(2);
    end
    
    %     raw = raws.data - mean(raws.data);
    a(n) = toc;
    n = n+1
end