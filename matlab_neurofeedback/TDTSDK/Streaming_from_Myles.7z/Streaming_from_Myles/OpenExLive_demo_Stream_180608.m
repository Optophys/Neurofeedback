%% Stream Example
%
% <html>
% Read a streaming data store into Matlab from Tank server during a recording <br>
% </html>

%% Housekeeping
% Clear workspace and close existing figures. Add SDK directories to Matlab
% path.
close all; clc;
% [MAINEXAMPLEPATH,name,ext] = fileparts(cd); % \TDTMatlabSDK\Examples
% [SDKPATH,name,ext] = fileparts(MAINEXAMPLEPATH); % \TDTMatlabSDK
% addpath(genpath(SDKPATH));

%%
DA = actxcontrol('TDevAcc.X'); %call the TDevAcc active x controls
DA.ConnectServer('Local') %connect to your local TDT server
DA.GetTankName %This will tell you your tank path
DA.GetSysMode %This command tells you what mode workbench is in
DA.GetDeviceRCO('RZ2') %this tells you the circuit you are running 

%set workbench to preview
DA.SetSysMode(2); %2 is preview, 3 is record, 0 is idle
%%

%write to your parameter tag
DA.SetTargetVal('RZ2.percentile',40)


%% Setup
EVENT = 'test';
t = OpenExLive();
t.VERBOSE = false;

%% Main Loop
first_pass = true;
while 1
    
    % slow it down
    pause(1)
    
    % get the most recent data, exit loop if the block has stopped.
    t.update();

    % grab the latest events
    r = t.get_data(EVENT);
    if isstruct(r)
        
        % plot them
        ts = linspace(t.T1, t.T2, max(size(r.data))-1);
        plot(ts, r.data(:,1:end-1)')
        title(EVENT)
        xlabel('Time, s')
        ylabel('V')
        axis tight
        
        % force the plots to update
        try
            snapnow
        catch
            drawnow
        end
    end
    
    % for publishing, end early
    if exist('quitEarly','var') && t.T2 > 30
        break
    end
end