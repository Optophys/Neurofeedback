%% Housekeeping by Golan
clearvars -except z zz
close all; clc;
SDKPATH = 'C:\MatlabPrograms\TDTSDK\Streaming_from_Myles';
addpath(genpath(SDKPATH));
load([SDKPATH '\offline_percentiles.mat']); %file with variable Y, which has "clean" power percentiles calculated offline on rat 206, 171205 
%% Setup
EVENT1 = 'Powr';
EVENT2 = 'test';
EVENT3 = 'arts';
EVENT4 = 'perc';
t = OpenExLive();
t.VERBOSE = false;

%% Parameters
cfg = [];
cfg.freqs           = 15:30;    %to plot, in Hz
cfg.medians_time    = 10;       %in seconds
cfg.group_delay     = 130;      %in samples
cfg.art_thrsh       = 450;      %raw LFP to be rejected, in uV
cfg.art_time        = 300;      %rejected time around artifact, in samples
cfg.do_plot         = 0;        %bool, 1 means plotting
cfg.do_LFP_artifact = 0;        %bool, 1 means do artifact removal from raw data

%% Main Loop
if cfg.do_plot, figure('position',[314 396 1574 707]); end
first_pass = true;
b = true;
n = 1;
prev_samp = 0;
last_samp = 0;

whole_arts      = [];
whole_pows      = [];
whole_raws      = [];
whole_arts.LFP  = [];
whole_arts.Pix  = [];
LFP_clean       = [];
Pix_clean       = [];
LFP_debt        = [];
Pix_debt        = [];

while b
    % slow it down
    pause(1)
    
    % get the most recent data, exit loop if the block has stopped.
    tic
    try t.update();
    catch b=0; disp('Block stopped?'); continue; end
    
    % grab the latest events
    pows = t.get_data(EVENT1); %estimated power in 1:32 Hz
    whole_pows = [whole_pows, pows.data];
    
    raws = t.get_data(EVENT2); %raw LDP data used to calculate power
    whole_raws = [whole_raws, raws.data];
        
    arts = t.get_data(EVENT3); %boolean, artifact detected in the LFP(1) or power (2)
    new_arts.LFP = find(arts.data(1,:));
    new_arts.Pix = find(arts.data(2,:));
    whole_arts.LFP = [whole_arts.LFP, new_arts.LFP];
    whole_arts.Pix = [whole_arts.Pix, new_arts.Pix];
    
    perc = t.get_data(EVENT4); %the target percentile for threshold
    p = perc.data(find(perc.data,1,'last')); %attention! will be updated when catch memory is read (usually after 6 sec).
    
    % calculations and plotting
    if isstruct(pows)
        siz = size(pows.data);
        last_samp = prev_samp + siz(2);
        samps = prev_samp+1 : last_samp;
        
        % remove gross artifacts
        Pix = pows.data;
        Pix (:,1:Pix_debt) = NaN; % put NaNs at the "debt" from the previous read
        Pix_debt = [];
        % Put NaNs around the artifacts
        for arin = new_arts.Pix %clean the LFP. can be removed in the end (the power is the important).
            if arin <= cfg.art_time
                Pix (:,1 : arin + cfg.art_time) = NaN;
                if ~isempty(Pix_clean) %Put NaNs also in the previous read
                    Pix_clean(:,end - (cfg.art_time-arin) : end) = NaN;
                end
            elseif arin >= (siz(2) - cfg.art_time)
                Pix (:,arin - cfg.art_time : end) = NaN;
                Pix_debt = cfg.art_time - (siz(2)-arin); %keep "NaN debt" for the nexe read
            else
                Pix (:,arin - cfg.art_time : arin + cfg.art_time) = NaN;
            end
        end
        Pix_clean = [Pix_clean, Pix];
        
        perc_samps = floor(cfg.medians_time * pows.fs);
        if size(Pix_clean,2) > perc_samps
            THRESHOLDS = prctile(Pix_clean(:,end-perc_samps : end),p,2); %takes ~5ms
        else %before having enough values, use percentiles of recorded data
            col = find(Y.percentiles == p); %p must be in 80:0.5:99.5
            THRESHOLDS = Y.values(:,col);
        end
        figure(2); hold on
        plot(THRESHOLDS(15:30))
        
        if cfg.do_LFP_artifact
            LFP = raws.data;
            LFP (1:LFP_debt) = NaN;
            LFP_debt  = [];
            for arin = new_arts.LFP %clean the LFP. can be removed in the end (the power is the important).
                if arin <= cfg.art_time
                    LFP   (1 : arin + cfg.art_time) = NaN;
                    if ~isempty(LFP_clean) %Put NaNs also in the previous read
                        LFP_clean(end - (cfg.art_time-arin) : end) = NaN;
                    end
                elseif arin >= (siz(2) - cfg.art_time)
                    LFP   (arin - cfg.art_time : end) = NaN;
                    LFP_debt = cfg.art_time - (siz(2)-arin); %keep "NaN debt" for the nexe read
                else
                    LFP   (arin - cfg.art_time : arin + cfg.art_time) = NaN;
                end
            end
            LFP_clean = [LFP_clean, LFP];
        end
        
        if cfg.do_plot
            subplot(4,1,1:3);
            ts = samps / pows.fs;
            imagesc(ts, cfg.freqs, pows.data(cfg.freqs,:));
            axis xy; colormap jet; colorbar('northoutside');
            title('Power'); ylabel('Frequency (Hz)')
            
            subplot(414);
            % use the same time stamps for raw as for power
            try plot(ts,whole_raws(:,samps - cfg.group_delay)'); end
            set(gca,'xlim',[ts(1), ts(end)]);
            title('Raw'); xlabel('Time (sec)'); ylabel('\muV');
        end
                
        prev_samp = last_samp;
        prev_samps(n) = last_samp; %used to store the data acquisition points. Useful for debugging
    end    
    
    a(n) = toc;
    n = n+1;
end